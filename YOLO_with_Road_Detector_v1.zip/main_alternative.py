"""
    Created on Wed Jun 28 01:36:48 2017
    @author: Brilian
"""
import cv2
from source.GUI         import runGUI
from source.YOLO_TF     import YOLO_TF
from source.lane_lines  import annotate_image_array
from source.arduino_cmd import updateDirection, runArduino
from time               import time

def runVideo(filename, yolo, canny_low, canny_high, road_width, gauss_kernel):
  ser = runArduino() #find arduino's port
  video = cv2.VideoCapture(filename) #read video
  start, ctr, road_points = time(), 0, []
  text = "FPS: 0, Runtime: 0, Offside: 0 meter"
  while video.isOpened:
    ok, frame = video.read()
    offside = 0.
    if ok:
      try:
        frame, offside, road_points = annotate_image_array( frame, canny_low, canny_high, gauss_kernel, road_width )
      except:
        print("Warning! road is not detected...")
      info, obj_detected, runtime =  yolo.detect_from_cvmat(frame, road_points)
      ctr += 1                
      ctr, text, start = updateRuntime(obj_detected, start, ctr, str(runtime), text )    
      showInfo(obj_detected, offside, info, text)
      updateDirection(offside) #give arduino command of offside position in here
      cv2.imshow("Self-Driving Car Team", obj_detected)
      
      if cv2.waitKey(1) & 0xFF == ord('q'): break
    else:
      break
  video.release()
  cv2.destroyAllWindows()

def updateRuntime(img, start, ctr, runtime, text):
  end = time()
  if end - start >= 1.:
    text = "FPS: " + str(ctr) + ", Runtime: " + runtime
    cv2.putText(img, text, (20, 20), cv2.FONT_HERSHEY_COMPLEX_SMALL, .6, (0,0,255))
    return 0, text, end
  return ctr, text, start

def showInfo(img, offside, info, text):
  cv2.putText(img, text + ", Offside: " + str(offside) + " meter", (20, 20), cv2.FONT_HERSHEY_COMPLEX_SMALL, .6, (0,0,255))
  cv2.putText(img, "Total object: " + str( info ), (20, 40), cv2.FONT_HERSHEY_COMPLEX_SMALL, .6, (0,0,255))

if __name__ == "__main__":
  print("Loading Yolo...")
  yolo = YOLO_TF()

  print("Loading Pre-setting...")
  try:
    canny_low, canny_high, road_width, gauss_kernel = runGUI()
    filename = ["test/RoadLineTesting.mp4","test/challenge.mp4","test/challenge2.mp4",
                "test/solidYellowLeft.mp4","test/solidWhiteRight.mp4"]

    print("Running Video...")
    runVideo(filename[0], yolo, int(canny_low), int(canny_high), float(road_width), int(gauss_kernel) )
    print("Closing the video...")
  except:
    print("Closing the Pre-setting and Video...")