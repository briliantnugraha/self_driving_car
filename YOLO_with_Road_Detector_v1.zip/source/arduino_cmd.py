from platform 	import system
from serial 	import Serial
from time 		import sleep

def updateDirection(offside, ser = 1, text = ''):
	print ("Sending " + str(offside) + " command")
	if offside < 0: text = "left"
	else: text = "right"
	if ser is not None:
		if text == "left":
			print ("please steer " + text) 
			#ser.write(b'1')
		elif text == "top": 
			print ("please slow down: " + text ) 
			#ser.write(b'2')
		elif text == "right": 
			print ("please steer " + text) 
			#ser.write(b'3')
		else:
			print ("please speedup: " + text) 
			#ser.write(b'4')

def runArduino():
	ser=None
	try:
		if platform.system() == 'Linux':
			ser = Serial("/dev/ttyUSB0", 115200)   # open serial port that Arduino is using
		else:
			ser = Serial("COM5", 115200)   # open serial port that Arduino is using
		print (ser)                         # print serial config
		sleep(1)
		return ser		
	except:
		print ("Arduino is not connected!")	
		return None