import easygui          as eg

def printInfo(info, lenInfo):
  temp = "\nTotal object: " + str( lenInfo )
  for val in info: temp += "\n" + val
  return temp

def runGUI():
  title = "Setting Confirmation"
  msg = "Do you want to use default setting?"
  fieldNames = ["Canny Low: ", "Canny High: ", "Road Width: ", "Gaussian Kernel: "]
  fieldValues = [50, 150, 2.5, 3]
  mBoxes = eg.multenterbox(msg, title, fieldNames, fieldValues)
  
  # make sure that none of the fields was left blank
  status = True
  while status == True:
      status, mBoxes = checkInputGUI(mBoxes, title, fieldNames, fieldValues)
      if mBoxes == None: print( "The GUI has not been set!" )
  return mBoxes

def checkInputGUI(mBoxes, title, fieldNames, fieldValues):
  if mBoxes == None: return False, None
  msg_error = ""
  for i in range(len(fieldNames)):
    if mBoxes[i] == "": msg_error += fieldNames[i] +' is a required field.\n'
  if msg_error == "":
    return False, mBoxes # no problems found
  else:
    mBoxes = eg.multenterbox(msg_error, title, fieldNames, fieldValues)
    return True, mBoxes