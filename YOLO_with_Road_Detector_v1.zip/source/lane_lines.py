import numpy as np
import cv2

# Global parameters
# Region-of-interest vertices, We want a trapezoid shape, with bottom edge at the bottom of the image
trap_bottom_width = 0.85  # width of bottom edge of trapezoid, expressed as percentage of image width
trap_top_width = 0.07  # ditto for top edge of trapezoid
trap_height = 0.4  # height of the trapezoid expressed as percentage of image height

# Hough Transform
rho = 2 # distance resolution in pixels of the Hough grid
theta = 1 * np.pi/180 # angular resolution in radians of the Hough grid
threshold = 15	 # minimum number of votes (intersections in Hough grid cell)
min_line_length = 10 #minimum number of pixels making up a line
max_line_gap = 20	# maximum gap in pixels between connectable line segments

# Helper functions
def grayscale(img):
	return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	
def canny(img, low_threshold, high_threshold):
	return cv2.Canny(img, low_threshold, high_threshold)

def gaussian_blur(img, kernel_size):
	return cv2.GaussianBlur(img, (kernel_size, kernel_size), 0)

def region_of_interest(img, vertices):
	#defining a blank mask to start with
	mask = np.zeros_like(img)   
	
	#defining a 3 channel or 1 channel color to fill 
   	#the mask with depending on the input image
	if len(img.shape) > 2:
		channel_count = img.shape[2]  # i.e. 3 or 4 depending on your image
		ignore_mask_color = (255,) * channel_count
	else:
		ignore_mask_color = 255
		
	#filling pixels inside the polygon defined by "vertices" with the fill color	
	cv2.fillPoly(mask, vertices, ignore_mask_color)
	
	#returning the image only where mask pixels are nonzero
	masked_image = cv2.bitwise_and(img, mask)
	return masked_image

def draw_lines(img, lines, imshape, ROAD_WIDTH, color=[255, 255, 0], thickness=4):
	# In case of error, don't draw the line(s)
	if lines is None or len(lines) == 0: return
	draw_right, draw_left, offside = True, True, 0.
	img_x_center = img.shape[1] / 2  # x coordinate of center of image

	# Find slopes of all lines
	# But only care about lines where abs(slope) > slope_threshold
	slope_threshold = 0.5
	# Split lines into right_lines and left_lines
	# Right/left lane lines must have positive/negative slope,
	# and be on the right/left half of the image
	right_lines_x = []
	right_lines_y = []
	left_lines_x = []
	left_lines_y = []
	for line in lines:
		x1, y1, x2, y2 = line[0]
		
		# Calculate slope
		if x2 - x1 == 0.:  # corner case, avoiding division by 0
			slope = 999.  # practically infinite slope
		else:
			slope = (y2 - y1) / (x2 - x1)
			
		# Filter lines based on slope
		if abs(slope) > slope_threshold:			
			if slope > 0 and x1 > img_x_center and x2 > img_x_center:
				right_lines_x.append(x1)
				right_lines_x.append(x2)
				right_lines_y.append(y1)
				right_lines_y.append(y2)
			elif slope < 0 and x1 < img_x_center and x2 < img_x_center:
				left_lines_x.append(x1)
				left_lines_x.append(x2)			
				left_lines_y.append(y1)
				left_lines_y.append(y2)	
			
	# Run linear regression to find best fit line for right and left lane lines
	# Right lane lines
	if len(right_lines_x) > 0:
		right_m, right_b = np.polyfit(right_lines_x, right_lines_y, 1)  # y = m*x + b
	else:
		right_m, right_b = 1, 1
		draw_right = False
		
	# Left lane lines		
	if len(left_lines_x) > 0:
		left_m, left_b = np.polyfit(left_lines_x, left_lines_y, 1)  # y = m*x + b
	else:
		left_m, left_b = 1, 1
		draw_left = False
	
	# Find 2 end points for right and left lines, used for drawing the line
	# y = m*x + b --> x = (y - b)/m
	y1, y2 = imshape[0], imshape[0] * (1 - trap_height)
	right_x1 = (y1 - right_b) / right_m
	right_x2 = (y2 - right_b) / right_m
	left_x1 = (y1 - left_b) / left_m
	left_x2 = (y2 - left_b) / left_m
	
	# Convert calculated end points from float to int
	y1, y2 = int(y1), int(y2)
	right_x1, right_x2 = int(right_x1), int(right_x2)
	left_x1, left_x2 = int(left_x1), int(left_x2)

	# Draw middle line from line images, and road_points
	middle_y = int( (y1 + y2) / 2 )
	middle_right_x = int( (right_x1 + right_x2) / 2 )
	middle_left_x = int( (left_x1 + left_x2) / 2 )	
	points = [ [right_x1, y1], [middle_right_x, middle_y], 
			[middle_left_x, middle_y], [left_x1, y1] ]

	if draw_right and draw_left:
		#draw the road lane
		cv2.fillPoly(img = img, pts = np.int32([points]), color = (255,0,255))
		
		#draw the middle x line
		middle_x = [int( (right_x1+left_x1)/2), int( (right_x2+left_x2)/2)]
		cv2.line(img, (middle_x[0] , y1), (middle_x[1], middle_y), [0, 255, 0], thickness)
		
		# compute the offside w.r.t the road width standard in each country
		offside = round((middle_x[0] - img_x_center)*ROAD_WIDTH / imshape[1],2)
	return offside, points        
	
def hough_lines(img, rho, theta, threshold, min_line_len, max_line_gap, imshape, ROAD_WIDTH):
	lines = cv2.HoughLinesP(img, rho, theta, threshold, np.array([]), minLineLength=min_line_len, maxLineGap=max_line_gap)
	line_img = np.zeros((*img.shape, 3), dtype=np.uint8)  # 3-channel RGB image
	offside, points = draw_lines(line_img, lines, imshape, ROAD_WIDTH)
	return line_img, offside, points

def weighted_img(img, initial_img, α=0.8, β=1., λ=0.):
	"""The result image is computed as follows: initial_img * α + img * β + λ"""
	return cv2.addWeighted(initial_img, α, img, β, λ)

def filter_colors(image):
	# Filter white pixels
	white_threshold = 230
	lower_white = np.array([white_threshold, white_threshold, white_threshold])
	upper_white = np.array([255, 255, 255])
	white_mask = cv2.inRange(image, lower_white, upper_white)
	white_image = cv2.bitwise_and(image, image, mask=white_mask)

	# Filter yellow pixels
	hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
	lower_yellow = np.array([20,100,100])
	upper_yellow = np.array([110,255,255])
	yellow_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
	yellow_image = cv2.bitwise_and(image, image, mask=yellow_mask)
	
	# Combine the two above images
	return cv2.addWeighted(white_image, 1., yellow_image, 1., 0.)

def annotate_image_array(image_in, low_threshold, high_threshold, kernel_size, ROAD_WIDTH):
	# Only keep white and yellow pixels in the image, all other pixels become black
	image = filter_colors(image_in)
	gray = grayscale(image) # change rgb to grayscale image
	blur_gray = gaussian_blur(gray, kernel_size) # Apply Gaussian smoothing	
	edges = canny(blur_gray, low_threshold, high_threshold) # Canny Edge Detector

	# Create masked edges using trapezoid-shaped region-of-interest
	imshape = image.shape
	vertices = np.array([[((imshape[1] * (1 - trap_bottom_width)) // 2, imshape[0]),\
		((imshape[1] * (1 - trap_top_width)) // 2, imshape[0] - imshape[0] * trap_height),\
		(imshape[1] - (imshape[1] * (1 - trap_top_width)) // 2, imshape[0] - imshape[0] * trap_height),\
		(imshape[1] - (imshape[1] * (1 - trap_bottom_width)) // 2, imshape[0])]]\
		, dtype=np.int32)
	masked_edges = region_of_interest(edges, vertices)

	# Run Hough on edge detected image
	line_image, offside, points  = hough_lines(masked_edges, rho, theta, threshold, min_line_length, max_line_gap, imshape, ROAD_WIDTH)
	
	# Draw lane lines on the original image
	initial_image = image_in.astype('uint8')
	annotated_image = weighted_img(line_image, initial_image)	
	return annotated_image, offside, points